package springXML.beans;

import java.util.ArrayList;

public class Cart {
    private ArrayList<Item> items = new ArrayList();
}
